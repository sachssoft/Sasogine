using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using System.Diagnostics;
using System.Text;

namespace SasogineShaderGenerator;

public sealed partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private async void BrowseFx_Click(object? sender, RoutedEventArgs e)
    {
        var files = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = "Select MonoGame FX shader",
            AllowMultiple = false,
            FileTypeFilter = [new FilePickerFileType("MonoGame Effect") { Patterns = ["*.fx"] }]
        });

        if (files.Count == 0)
            return;

        FxPathBox.Text = files[0].TryGetLocalPath();
        UpdateOutputPath();
    }

    private void FxPathBox_TextChanged(object? sender, TextChangedEventArgs e)
    {
        UpdateOutputPath();
    }

    private void TargetBox_SelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        UpdateOutputPath();
    }

    private void UpdateOutputPath()
    {
        if (OutputPathBox is null || FxPathBox is null || TargetBox is null)
            return;

        var input = FxPathBox.Text?.Trim();
        if (string.IsNullOrWhiteSpace(input))
        {
            OutputPathBox.Text = string.Empty;
            return;
        }

        var directory = Path.GetDirectoryName(input);
        var fileName = Path.GetFileNameWithoutExtension(input);
        var suffix = GetTarget().Suffix;
        var outputName = $"{fileName}_{suffix}.mgfxo";

        OutputPathBox.Text = string.IsNullOrWhiteSpace(directory)
            ? outputName
            : Path.Combine(directory, outputName);
    }

    private async void Compile_Click(object? sender, RoutedEventArgs e)
    {
        var input = FxPathBox.Text?.Trim();
        var output = OutputPathBox.Text?.Trim();
        var compiler = CompilerPathBox.Text?.Trim();

        if (string.IsNullOrWhiteSpace(input) || !File.Exists(input))
        {
            SetLog("FX file does not exist.");
            return;
        }

        if (string.IsNullOrWhiteSpace(output))
        {
            SetLog("Output path is empty.");
            return;
        }

        if (string.IsNullOrWhiteSpace(compiler))
        {
            SetLog("mgfxc path is empty.");
            return;
        }

        var target = GetTarget().Profile;
        var outputDirectory = Path.GetDirectoryName(output);
        if (!string.IsNullOrWhiteSpace(outputDirectory))
            Directory.CreateDirectory(outputDirectory);

        CompileButton.IsEnabled = false;
        SetLog($"Compiling {Path.GetFileName(input)} for {target}...{Environment.NewLine}");

        try
        {
            var result = await MgfxCompiler.CompileAsync(compiler, input, output, target);
            var log = new StringBuilder();
            if (!string.IsNullOrWhiteSpace(result.StandardOutput))
                log.AppendLine(result.StandardOutput.TrimEnd());
            if (!string.IsNullOrWhiteSpace(result.StandardError))
                log.AppendLine(result.StandardError.TrimEnd());
            log.AppendLine(result.ExitCode == 0 ? $"Success: {output}" : $"Failed with exit code {result.ExitCode}.");
            SetLog(log.ToString());
        }
        catch (Exception ex)
        {
            SetLog(ex.ToString());
        }
        finally
        {
            CompileButton.IsEnabled = true;
        }
    }

    private (string Profile, string Suffix) GetTarget() => TargetBox.SelectedIndex switch
    {
        1 => ("DirectX_11", "dx"),
        2 => ("DirectX_12", "dx12"),
        3 => ("Vulkan", "vk"),
        _ => ("OpenGL", "gl")
    };

    private void SetLog(string text) => LogBox.Text = text;
}

internal static class MgfxCompiler
{
    public static async Task<CompileResult> CompileAsync(string compilerPath, string inputPath, string outputPath, string profile, CancellationToken cancellationToken = default)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = compilerPath,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        startInfo.ArgumentList.Add(inputPath);
        startInfo.ArgumentList.Add(outputPath);
        startInfo.ArgumentList.Add($"/Profile:{profile}");

        using var process = new Process { StartInfo = startInfo };
        process.Start();

        var stdoutTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
        var stderrTask = process.StandardError.ReadToEndAsync(cancellationToken);

        await process.WaitForExitAsync(cancellationToken);

        return new CompileResult(process.ExitCode, await stdoutTask, await stderrTask);
    }
}

internal readonly record struct CompileResult(int ExitCode, string StandardOutput, string StandardError);
