using FontStashSharp;
using Microsoft.Xna.Framework;
using Sachssoft.Sasodoc;
using Sachssoft.Sasogine.Common;
using Sachssoft.Sasogine.Gameplay;
using Sachssoft.Sasogine.Geometry;
using System;
using System.Collections.Generic;
using System.Drawing;

namespace Sachssoft.Sasogine.Markup.Serialization
{
    /// <summary>
    /// Provides markup serialization extensions for Sasogine engine value types.
    /// </summary>
    public static class EngineExtensions
    {
        #region Point2
        /// <summary>
        /// Reads a Point2 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Point2 ReadPoint2(this FormatReaderBase reader, string property, Point2 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var x = childReader.ReadSingle(nameof(Point2.X), fallback.X);
            var y = childReader.ReadSingle(nameof(Point2.Y), fallback.Y);

            return (new Point2(x, y));
        }

        /// <summary>
        /// Writes a Point2 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePoint2(this FormatWriterBase writer, string property, Point2 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Point2.X), value.X);
            childWriter.WriteSingle(nameof(Point2.Y), value.Y);

            writer.Write(property, childWriter);
        }
        #endregion

        #region Point3
        /// <summary>
        /// Reads a Point3 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Point3 ReadPoint3(this FormatReaderBase reader, string property, Point3 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var x = childReader.ReadSingle(nameof(Point3.X), fallback.X);
            var y = childReader.ReadSingle(nameof(Point3.Y), fallback.Y);
            var z = childReader.ReadSingle(nameof(Point3.Z), fallback.Z);

            return (new Point3(x, y, z));
        }

        /// <summary>
        /// Writes a Point3 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePoint3(this FormatWriterBase writer, string property, Point3 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Point3.X), value.X);
            childWriter.WriteSingle(nameof(Point3.Y), value.Y);
            childWriter.WriteSingle(nameof(Point3.Z), value.Z);

            writer.Write(property, childWriter);
        }
        #endregion

        #region PixelPoint2
        /// <summary>
        /// Reads a PixelPoint2 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static PixelPoint2 ReadPixelPoint2(this FormatReaderBase reader, string property, PixelPoint2 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var x = childReader.ReadInt32(nameof(PixelPoint2.X), fallback.X);
            var y = childReader.ReadInt32(nameof(PixelPoint2.Y), fallback.Y);

            return (new PixelPoint2(x, y));
        }

        /// <summary>
        /// Writes a PixelPoint2 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePixelPoint2(this FormatWriterBase writer, string property, PixelPoint2 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteInt32(nameof(PixelPoint2.X), value.X);
            childWriter.WriteInt32(nameof(PixelPoint2.Y), value.Y);

            writer.Write(property, childWriter);
        }
        #endregion

        #region PixelPoint3
        /// <summary>
        /// Reads a PixelPoint3 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static PixelPoint3 ReadPixelPoint3(this FormatReaderBase reader, string property, PixelPoint3 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var x = childReader.ReadInt32(nameof(PixelPoint3.X), fallback.X);
            var y = childReader.ReadInt32(nameof(PixelPoint3.Y), fallback.Y);
            var depth = childReader.ReadInt32(nameof(PixelPoint3.Z), fallback.Z);

            return (new PixelPoint3(x, y, depth));
        }

        /// <summary>
        /// Writes a PixelPoint3 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePixelPoint3(this FormatWriterBase writer, string property, PixelPoint3 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteInt32(nameof(PixelPoint3.X), value.X);
            childWriter.WriteInt32(nameof(PixelPoint3.Y), value.Y);
            childWriter.WriteInt32(nameof(PixelPoint3.Z), value.Z);

            writer.Write(property, childWriter);
        }
        #endregion

        #region Size2
        /// <summary>
        /// Reads a Size2 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Size2 ReadSize2(this FormatReaderBase reader, string property, Size2 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var width = childReader.ReadSingle(nameof(Size2.Width), fallback.Width);
            var height = childReader.ReadSingle(nameof(Size2.Height), fallback.Height);

            return (new Size2(width, height));
        }

        /// <summary>
        /// Writes a Size2 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WriteSize2(this FormatWriterBase writer, string property, Size2 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Size2.Width), value.Width);
            childWriter.WriteSingle(nameof(Size2.Height), value.Height);

            writer.Write(property, childWriter);
        }
        #endregion

        #region Size3
        /// <summary>
        /// Reads a Size3 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Size3 ReadSize3(this FormatReaderBase reader, string property, Size3 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var width = childReader.ReadSingle(nameof(Size3.Width), fallback.Width);
            var height = childReader.ReadSingle(nameof(Size3.Height), fallback.Height);
            var depth = childReader.ReadSingle(nameof(Size3.Depth), fallback.Depth);

            return (new Size3(width, height, depth));
        }

        /// <summary>
        /// Writes a Size3 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WriteSize3(this FormatWriterBase writer, string property, Size3 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Size3.Width), value.Width);
            childWriter.WriteSingle(nameof(Size3.Height), value.Height);
            childWriter.WriteSingle(nameof(Size3.Depth), value.Depth);

            writer.Write(property, childWriter);
        }
        #endregion

        #region PixelSize2
        /// <summary>
        /// Reads a PixelSize2 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static PixelSize2 ReadPixelSize2(this FormatReaderBase reader, string property, PixelSize2 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var width = childReader.ReadInt32(nameof(PixelSize2.Width), fallback.Width);
            var height = childReader.ReadInt32(nameof(PixelSize2.Height), fallback.Height);

            return (new PixelSize2(width, height));
        }

        /// <summary>
        /// Writes a PixelSize2 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePixelSize2(this FormatWriterBase writer, string property, PixelSize2 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteInt32(nameof(PixelSize2.Width), value.Width);
            childWriter.WriteInt32(nameof(PixelSize2.Height), value.Height);

            writer.Write(property, childWriter);
        }
        #endregion

        #region PixelSize3
        /// <summary>
        /// Reads a PixelSize3 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static PixelSize3 ReadPixelSize3(this FormatReaderBase reader, string property, PixelSize3 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var width = childReader.ReadInt32(nameof(PixelSize3.Width), fallback.Width);
            var height = childReader.ReadInt32(nameof(PixelSize3.Height), fallback.Height);
            var depth = childReader.ReadInt32(nameof(PixelSize3.Depth), fallback.Depth);

            return (new PixelSize3(width, height, depth));
        }

        /// <summary>
        /// Writes a PixelSize3 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePixelSize3(this FormatWriterBase writer, string property, PixelSize3 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteInt32(nameof(PixelSize3.Width), value.Width);
            childWriter.WriteInt32(nameof(PixelSize3.Height), value.Height);
            childWriter.WriteInt32(nameof(PixelSize3.Depth), value.Depth);

            writer.Write(property, childWriter);
        }
        #endregion

        #region Insets2
        /// <summary>
        /// Reads a Insets2 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Insets2 ReadInsets2(this FormatReaderBase reader, string property, Insets2 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var left = childReader.ReadSingle(nameof(Insets2.Left), fallback.Left);
            var top = childReader.ReadSingle(nameof(Insets2.Top), fallback.Top);
            var right = childReader.ReadSingle(nameof(Insets2.Right), fallback.Right);
            var bottom = childReader.ReadSingle(nameof(Insets2.Bottom), fallback.Bottom);

            return new Insets2(left, top, right, bottom);
        }

        /// <summary>
        /// Writes a Insets2 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WriteInsets2(this FormatWriterBase writer, string property, Insets2 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Insets2.Left), value.Left);
            childWriter.WriteSingle(nameof(Insets2.Top), value.Top);
            childWriter.WriteSingle(nameof(Insets2.Right), value.Right);
            childWriter.WriteSingle(nameof(Insets2.Bottom), value.Bottom);

            writer.Write(property, childWriter);
        }
        #endregion

        #region Insets3
        /// <summary>
        /// Reads a Insets3 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Insets3 ReadInsets3(this FormatReaderBase reader, string property, Insets3 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var left = childReader.ReadSingle(nameof(Insets3.Left), fallback.Left);
            var top = childReader.ReadSingle(nameof(Insets3.Top), fallback.Top);
            var front = childReader.ReadSingle(nameof(Insets3.Front), fallback.Front);
            var right = childReader.ReadSingle(nameof(Insets3.Right), fallback.Right);
            var bottom = childReader.ReadSingle(nameof(Insets3.Bottom), fallback.Bottom);
            var back = childReader.ReadSingle(nameof(Insets3.Back), fallback.Back);

            return new Insets3(left, top, front, right, bottom, back);
        }

        /// <summary>
        /// Writes a Insets3 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WriteInsets3(this FormatWriterBase writer, string property, Insets3 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Insets3.Left), value.Left);
            childWriter.WriteSingle(nameof(Insets3.Top), value.Top);
            childWriter.WriteSingle(nameof(Insets3.Front), value.Front);
            childWriter.WriteSingle(nameof(Insets3.Right), value.Right);
            childWriter.WriteSingle(nameof(Insets3.Bottom), value.Bottom);
            childWriter.WriteSingle(nameof(Insets3.Back), value.Back);

            writer.Write(property, childWriter);
        }
        #endregion

        #region PixelInsets2
        /// <summary>
        /// Reads a PixelInsets2 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static PixelInsets2 ReadPixelInsets2(this FormatReaderBase reader, string property, PixelInsets2 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var left = childReader.ReadInt32(nameof(PixelInsets2.Left), fallback.Left);
            var top = childReader.ReadInt32(nameof(PixelInsets2.Top), fallback.Top);
            var right = childReader.ReadInt32(nameof(PixelInsets2.Right), fallback.Right);
            var bottom = childReader.ReadInt32(nameof(PixelInsets2.Bottom), fallback.Bottom);

            return new PixelInsets2(left, top, right, bottom);
        }

        /// <summary>
        /// Writes a PixelInsets2 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePixelInsets2(this FormatWriterBase writer, string property, PixelInsets2 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteInt32(nameof(PixelInsets2.Left), value.Left);
            childWriter.WriteInt32(nameof(PixelInsets2.Top), value.Top);
            childWriter.WriteInt32(nameof(PixelInsets2.Right), value.Right);
            childWriter.WriteInt32(nameof(PixelInsets2.Bottom), value.Bottom);

            writer.Write(property, childWriter);
        }
        #endregion

        #region PixelInsets3
        /// <summary>
        /// Reads a PixelInsets3 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static PixelInsets3 ReadPixelInsets3(this FormatReaderBase reader, string property, PixelInsets3 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var left = childReader.ReadInt32(nameof(PixelInsets3.Left), fallback.Left);
            var top = childReader.ReadInt32(nameof(PixelInsets3.Top), fallback.Top);
            var front = childReader.ReadInt32(nameof(PixelInsets3.Front), fallback.Front);
            var right = childReader.ReadInt32(nameof(PixelInsets3.Right), fallback.Right);
            var bottom = childReader.ReadInt32(nameof(PixelInsets3.Bottom), fallback.Bottom);
            var back = childReader.ReadInt32(nameof(PixelInsets3.Back), fallback.Back);

            return new PixelInsets3(left, top, front, right, bottom, back);
        }

        /// <summary>
        /// Writes a PixelInsets3 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePixelInsets3(this FormatWriterBase writer, string property, PixelInsets3 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteInt32(nameof(PixelInsets3.Left), value.Left);
            childWriter.WriteInt32(nameof(PixelInsets3.Top), value.Top);
            childWriter.WriteInt32(nameof(PixelInsets3.Front), value.Front);
            childWriter.WriteInt32(nameof(PixelInsets3.Right), value.Right);
            childWriter.WriteInt32(nameof(PixelInsets3.Bottom), value.Bottom);
            childWriter.WriteInt32(nameof(PixelInsets3.Back), value.Back);

            writer.Write(property, childWriter);
        }
        #endregion

        #region Bounds2
        /// <summary>
        /// Reads a Bounds2 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Bounds2 ReadBounds2(this FormatReaderBase reader, string property, Bounds2 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var x = childReader.ReadSingle(nameof(Bounds2.X), fallback.X);
            var y = childReader.ReadSingle(nameof(Bounds2.Y), fallback.Y);
            var width = childReader.ReadSingle(nameof(Bounds2.Width), fallback.Width);
            var height = childReader.ReadSingle(nameof(Bounds2.Height), fallback.Height);

            return (new Bounds2(x, y, width, height));
        }

        /// <summary>
        /// Writes a Bounds2 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WriteBounds2(this FormatWriterBase writer, string property, Bounds2 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Bounds2.X), value.X);
            childWriter.WriteSingle(nameof(Bounds2.Y), value.Y);
            childWriter.WriteSingle(nameof(Bounds2.Width), value.Width);
            childWriter.WriteSingle(nameof(Bounds2.Height), value.Height);

            writer.Write(property, childWriter);
        }
        #endregion

        #region Bounds3
        /// <summary>
        /// Reads a Bounds3 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Bounds3 ReadBounds3(this FormatReaderBase reader, string property, Bounds3 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var x = childReader.ReadSingle(nameof(Bounds3.X), fallback.X);
            var y = childReader.ReadSingle(nameof(Bounds3.Y), fallback.Y);
            var z = childReader.ReadSingle(nameof(Bounds3.Z), fallback.Z);
            var width = childReader.ReadSingle(nameof(Bounds3.Width), fallback.Width);
            var height = childReader.ReadSingle(nameof(Bounds3.Height), fallback.Height);
            var depth = childReader.ReadSingle(nameof(Bounds3.Depth), fallback.Depth);

            return (new Bounds3(x, y, z, width, height, depth));
        }

        /// <summary>
        /// Writes a Bounds3 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WriteBounds3(this FormatWriterBase writer, string property, Bounds3 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Bounds3.X), value.X);
            childWriter.WriteSingle(nameof(Bounds3.Y), value.Y);
            childWriter.WriteSingle(nameof(Bounds3.Z), value.Z);
            childWriter.WriteSingle(nameof(Bounds3.Width), value.Width);
            childWriter.WriteSingle(nameof(Bounds3.Height), value.Height);
            childWriter.WriteSingle(nameof(Bounds3.Depth), value.Depth);

            writer.Write(property, childWriter);
        }
        #endregion

        #region PixelBounds2
        /// <summary>
        /// Reads a PixelBounds2 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static PixelBounds2 ReadPixelBounds2(this FormatReaderBase reader, string property, PixelBounds2 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var x = childReader.ReadInt32(nameof(PixelBounds2.X), fallback.X);
            var y = childReader.ReadInt32(nameof(PixelBounds2.Y), fallback.Y);
            var width = childReader.ReadInt32(nameof(PixelBounds2.Width), fallback.Width);
            var height = childReader.ReadInt32(nameof(PixelBounds2.Height), fallback.Height);

            return (new PixelBounds2(x, y, width, height));
        }

        /// <summary>
        /// Writes a PixelBounds2 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePixelBounds2(this FormatWriterBase writer, string property, PixelBounds2 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteInt32(nameof(PixelBounds2.X), value.X);
            childWriter.WriteInt32(nameof(PixelBounds2.Y), value.Y);
            childWriter.WriteInt32(nameof(PixelBounds2.Width), value.Width);
            childWriter.WriteInt32(nameof(PixelBounds2.Height), value.Height);

            writer.Write(property, childWriter);
        }
        #endregion

        #region PixelBounds3
        /// <summary>
        /// Reads a PixelBounds3 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static PixelBounds3 ReadPixelBounds3(this FormatReaderBase reader, string property, PixelBounds3 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var x = childReader.ReadInt32(nameof(PixelBounds3.X), fallback.X);
            var y = childReader.ReadInt32(nameof(PixelBounds3.Y), fallback.Y);
            var z = childReader.ReadInt32(nameof(PixelBounds3.Z), fallback.Z);
            var width = childReader.ReadInt32(nameof(PixelBounds3.Width), fallback.Width);
            var height = childReader.ReadInt32(nameof(PixelBounds3.Height), fallback.Height);
            var depth = childReader.ReadInt32(nameof(PixelBounds3.Depth), fallback.Depth);

            return (new PixelBounds3(x, y, z, width, height, depth));
        }

        /// <summary>
        /// Writes a PixelBounds3 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePixelBounds3(this FormatWriterBase writer, string property, PixelBounds3 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteInt32(nameof(PixelBounds3.X), value.X);
            childWriter.WriteInt32(nameof(PixelBounds3.Y), value.Y);
            childWriter.WriteInt32(nameof(PixelBounds3.Z), value.Z);
            childWriter.WriteInt32(nameof(PixelBounds3.Width), value.Width);
            childWriter.WriteInt32(nameof(PixelBounds3.Height), value.Height);
            childWriter.WriteInt32(nameof(PixelBounds3.Depth), value.Depth);

            writer.Write(property, childWriter);
        }
        #endregion

        #region Box2
        /// <summary>
        /// Reads a Box2 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Box2 ReadBox2(this FormatReaderBase reader, string property, Box2 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var minX = childReader.ReadSingle(nameof(Box2.MinX), fallback.MinX);
            var minY = childReader.ReadSingle(nameof(Box2.MinY), fallback.MinY);
            var maxX = childReader.ReadSingle(nameof(Box2.MaxX), fallback.MaxX);
            var maxY = childReader.ReadSingle(nameof(Box2.MaxY), fallback.MaxY);

            return (new Box2(minX, minY, maxX, maxY));
        }

        /// <summary>
        /// Writes a Box2 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WriteBox2(this FormatWriterBase writer, string property, Box2 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Box2.MinX), value.MinX);
            childWriter.WriteSingle(nameof(Box2.MinY), value.MinY);
            childWriter.WriteSingle(nameof(Box2.MaxX), value.MaxX);
            childWriter.WriteSingle(nameof(Box2.MaxY), value.MaxY);

            writer.Write(property, childWriter);
        }
        #endregion

        #region Box3
        /// <summary>
        /// Reads a Box3 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Box3 ReadBox3(this FormatReaderBase reader, string property, Box3 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var minX = childReader.ReadSingle(nameof(Box3.MinX), fallback.MinX);
            var minY = childReader.ReadSingle(nameof(Box3.MinY), fallback.MinY);
            var minZ = childReader.ReadSingle(nameof(Box3.MinZ), fallback.MinZ);
            var maxX = childReader.ReadSingle(nameof(Box3.MaxX), fallback.MaxX);
            var maxY = childReader.ReadSingle(nameof(Box3.MaxY), fallback.MaxY);
            var maxZ = childReader.ReadSingle(nameof(Box3.MaxZ), fallback.MaxZ);

            return (new Box3(minX, minY, minZ, maxX, maxY, maxZ));
        }

        /// <summary>
        /// Writes a Box3 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WriteBox3(this FormatWriterBase writer, string property, Box3 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Box3.MinX), value.MinX);
            childWriter.WriteSingle(nameof(Box3.MinY), value.MinY);
            childWriter.WriteSingle(nameof(Box3.MinZ), value.MinZ);
            childWriter.WriteSingle(nameof(Box3.MaxX), value.MaxX);
            childWriter.WriteSingle(nameof(Box3.MaxY), value.MaxY);
            childWriter.WriteSingle(nameof(Box3.MaxZ), value.MaxZ);

            writer.Write(property, childWriter);
        }
        #endregion

        #region PixelBox2
        /// <summary>
        /// Reads a PixelBox2 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static PixelBox2 ReadPixelBox2(this FormatReaderBase reader, string property, PixelBox2 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var minX = childReader.ReadInt32(nameof(PixelBox2.MinX), fallback.MinX);
            var minY = childReader.ReadInt32(nameof(PixelBox2.MinY), fallback.MinY);
            var maxX = childReader.ReadInt32(nameof(PixelBox2.MaxX), fallback.MaxX);
            var maxY = childReader.ReadInt32(nameof(PixelBox2.MaxY), fallback.MaxY);

            return (new PixelBox2(minX, minY, maxX, maxY));
        }

        /// <summary>
        /// Writes a PixelBox2 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePixelBox2(this FormatWriterBase writer, string property, PixelBox2 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteInt32(nameof(PixelBox2.MinX), value.MinX);
            childWriter.WriteInt32(nameof(PixelBox2.MinY), value.MinY);
            childWriter.WriteInt32(nameof(PixelBox2.MaxX), value.MaxX);
            childWriter.WriteInt32(nameof(PixelBox2.MaxY), value.MaxY);

            writer.Write(property, childWriter);
        }
        #endregion

        #region PixelBox3
        /// <summary>
        /// Reads a PixelBox3 value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static PixelBox3 ReadPixelBox3(this FormatReaderBase reader, string property, PixelBox3 fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var minX = childReader.ReadInt32(nameof(PixelBox3.MinX), fallback.MinX);
            var minY = childReader.ReadInt32(nameof(PixelBox3.MinY), fallback.MinY);
            var minZ = childReader.ReadInt32(nameof(PixelBox3.MinZ), fallback.MinZ);
            var maxX = childReader.ReadInt32(nameof(PixelBox3.MaxX), fallback.MaxX);
            var maxY = childReader.ReadInt32(nameof(PixelBox3.MaxY), fallback.MaxY);
            var maxZ = childReader.ReadInt32(nameof(PixelBox3.MaxZ), fallback.MaxZ);

            return (new PixelBox3(minX, minY, minZ, maxX, maxY, maxZ));
        }

        /// <summary>
        /// Writes a PixelBox3 value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WritePixelBox3(this FormatWriterBase writer, string property, PixelBox3 value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteInt32(nameof(PixelBox3.MinX), value.MinX);
            childWriter.WriteInt32(nameof(PixelBox3.MinY), value.MinY);
            childWriter.WriteInt32(nameof(PixelBox3.MinZ), value.MinZ);
            childWriter.WriteInt32(nameof(PixelBox3.MaxX), value.MaxX);
            childWriter.WriteInt32(nameof(PixelBox3.MaxY), value.MaxY);
            childWriter.WriteInt32(nameof(PixelBox3.MaxZ), value.MaxZ);

            writer.Write(property, childWriter);
        }
        #endregion

        #region LowTieredScore
        /// <summary>
        /// Reads a LowTieredScore value from the specified markup property.
        /// </summary>
        /// <typeparam name="TValue">The generic TValue type.</typeparam>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="readValueItem">The callback used to read an individual score value.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static LowTieredScore<TValue> ReadLowTieredScore<TValue>(
            this FormatReaderBase reader,
            string property,
            Func<FormatReaderBase, string, TValue> readValueItem,
            LowTieredScore<TValue> fallback = default
        )
             where TValue : struct, IComparable<TValue>
        {
            if (!reader.Contains(property))
                return fallback;

            var readerChild = reader.Read(property);

            if (readerChild == null)
                return fallback;

            var bronze = readValueItem(readerChild, nameof(LowTieredScore<TValue>.Bronze));
            var silver = readValueItem(readerChild, nameof(LowTieredScore<TValue>.Silver));
            var gold = readValueItem(readerChild, nameof(LowTieredScore<TValue>.Gold));

            return new LowTieredScore<TValue>(
                bronze: bronze,
                silver: silver,
                gold: gold
            );
        }

        /// <summary>
        /// Writes a LowTieredScore value to the specified markup property.
        /// </summary>
        /// <typeparam name="TValue">The generic TValue type.</typeparam>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        /// <param name="writeValueItem">The callback used to write an individual score value.</param>
        public static void WriteLowTieredScore<TValue>(
            this FormatWriterBase writer,
            string property,
            LowTieredScore<TValue> value,
            Action<FormatWriterBase, string, TValue?> writeValueItem
        )
             where TValue : struct, IComparable<TValue>
        {
            var writerChild = writer.CreateWriter();

            writeValueItem(writerChild, nameof(LowTieredScore<TValue>.Bronze), value.Bronze);
            writeValueItem(writerChild, nameof(LowTieredScore<TValue>.Silver), value.Silver);
            writeValueItem(writerChild, nameof(LowTieredScore<TValue>.Gold), value.Gold);
            writer.Write(property, writerChild);
        }
        #endregion

        #region TieredScore
        /// <summary>
        /// Reads a HighTieredScore value from the specified markup property.
        /// </summary>
        /// <typeparam name="TValue">The generic TValue type.</typeparam>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="readValueItem">The callback used to read an individual score value.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static HighTieredScore<TValue> ReadHighTieredScore<TValue>(
            this FormatReaderBase reader,
            string property,
            Func<FormatReaderBase, string, TValue> readValueItem,
            HighTieredScore<TValue> fallback = default
        )
             where TValue : struct, IComparable<TValue>
        {
            if (!reader.Contains(property))
                return fallback;

            var readerChild = reader.Read(property);

            if (readerChild == null)
                return fallback;

            var bronze = readValueItem(readerChild, nameof(HighTieredScore<TValue>.Bronze));
            var silver = readValueItem(readerChild, nameof(HighTieredScore<TValue>.Silver));
            var gold = readValueItem(readerChild, nameof(HighTieredScore<TValue>.Gold));

            return new HighTieredScore<TValue>(
                bronze: bronze,
                silver: silver,
                gold: gold
            );
        }

        /// <summary>
        /// Writes a HighTieredScore value to the specified markup property.
        /// </summary>
        /// <typeparam name="TValue">The generic TValue type.</typeparam>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        /// <param name="writeValueItem">The callback used to write an individual score value.</param>
        public static void WriteHighTieredScore<TValue>(
            this FormatWriterBase writer,
            string property,
            HighTieredScore<TValue> value,
            Action<FormatWriterBase, string, TValue?> writeValueItem
        )
             where TValue : struct, IComparable<TValue>
        {
            var writerChild = writer.CreateWriter();

            writeValueItem(writerChild, nameof(HighTieredScore<TValue>.Bronze), value.Bronze);
            writeValueItem(writerChild, nameof(HighTieredScore<TValue>.Silver), value.Silver);
            writeValueItem(writerChild, nameof(HighTieredScore<TValue>.Gold), value.Gold);
            writer.Write(property, writerChild);
        }
        #endregion

        #region Segment
        /// <summary>
        /// Reads a Segment value from the specified markup property.
        /// </summary>
        /// <param name="reader">The markup reader.</param>
        /// <param name="property">The property name.</param>
        /// <param name="fallback">The value returned when the property cannot be read.</param>
        /// <returns>The deserialized value, or the supplied fallback when no usable value is available.</returns>
        public static Segment ReadSegment(this FormatReaderBase reader, string property, Segment fallback)
        {
            var childReader = reader.Read(property);

            if (childReader == null)
                return fallback;

            var x1 = childReader.ReadSingle(nameof(Segment.X1), fallback.X1);
            var y1 = childReader.ReadSingle(nameof(Segment.Y1), fallback.Y1);
            var x2 = childReader.ReadSingle(nameof(Segment.X2), fallback.X2);
            var y2 = childReader.ReadSingle(nameof(Segment.Y2), fallback.Y2);

            return (new Segment(x1, y1, x2, y2));
        }

        /// <summary>
        /// Writes a Segment value to the specified markup property.
        /// </summary>
        /// <param name="writer">The markup writer.</param>
        /// <param name="property">The property name.</param>
        /// <param name="value">The value to write.</param>
        public static void WriteSegment(this FormatWriterBase writer, string property, Segment value)
        {
            var childWriter = writer.CreateWriter();

            childWriter.WriteSingle(nameof(Segment.X1), value.X1);
            childWriter.WriteSingle(nameof(Segment.Y1), value.Y1);
            childWriter.WriteSingle(nameof(Segment.X2), value.X2);
            childWriter.WriteSingle(nameof(Segment.Y2), value.Y2);

            writer.Write(property, childWriter);
        }
        #endregion
    }
}
