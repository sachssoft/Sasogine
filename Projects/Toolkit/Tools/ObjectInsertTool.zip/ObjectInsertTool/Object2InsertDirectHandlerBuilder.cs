using System;
using System.Collections.Generic;

namespace Sachssoft.Engine.Components.Tools
{
    /// <summary>
    /// Provides a fluent builder for creating 2D object insert handlers that directly manage engine objects.
    /// </summary>
    public sealed class Object2InsertDirectHandlerBuilder
    {
        private readonly IList<IEngineObject> _objectsSource;
        private readonly Func<IDefinition, IEngineObject> _createObject;
        private readonly Func<Object2InsertContext, IDefinition> _createDefinition;
        private Object2InsertMode _mode = Object2InsertMode.Free;
        private Func<IDefinition, IEngineObject, Object2InsertMode>? _modeSelector;
        private Action<IDefinition, IEngineObject, Object2InsertContext>? _attached;
        private Action<IDefinition, Object2InsertContext>? _drag;
        private Action<IDefinition, Object2InsertContext>? _complete;
        private Action<IDefinition, Object2InsertContext>? _cancel;
        private Action<IDefinition, IEngineObject, Object2InsertContext>? _release;

        private Object2InsertDirectHandlerBuilder(IList<IEngineObject> objectsSource,
            Func<IDefinition, IEngineObject> createObject, Func<Object2InsertContext, IDefinition> createDefinition)
        {
            _objectsSource = objectsSource;
            _createObject = createObject;
            _createDefinition = createDefinition;
        }

        /// <summary>Creates a new builder using a mutable engine object collection.</summary>
        public static Object2InsertDirectHandlerBuilder Create(IList<IEngineObject> objectsSource,
            Func<IDefinition, IEngineObject> createObject, Func<Object2InsertContext, IDefinition> createDefinition)
        {
            ArgumentNullException.ThrowIfNull(objectsSource);
            ArgumentNullException.ThrowIfNull(createObject);
            ArgumentNullException.ThrowIfNull(createDefinition);
            return new Object2InsertDirectHandlerBuilder(objectsSource, createObject, createDefinition);
        }

        /// <summary>Sets the insertion mode.</summary>
        public Object2InsertDirectHandlerBuilder WithMode(Object2InsertMode mode)
        {
            _mode = mode;
            _modeSelector = null;
            return this;
        }

        /// <summary>Sets a callback used to determine the insertion mode.</summary>
        public Object2InsertDirectHandlerBuilder WithMode(Func<IDefinition, IEngineObject, Object2InsertMode> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);
            _modeSelector = callback;
            return this;
        }

        /// <summary>Sets the callback invoked after the engine object has been added.</summary>
        public Object2InsertDirectHandlerBuilder OnAttached(Action<IDefinition, IEngineObject, Object2InsertContext> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);
            _attached = callback;
            return this;
        }

        /// <summary>Sets the callback invoked while the definition is being dragged.</summary>
        public Object2InsertDirectHandlerBuilder OnDrag(Action<IDefinition, Object2InsertContext> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);
            _drag = callback;
            return this;
        }

        /// <summary>Sets the callback invoked when insertion is completed.</summary>
        public Object2InsertDirectHandlerBuilder OnComplete(Action<IDefinition, Object2InsertContext> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);
            _complete = callback;
            return this;
        }

        /// <summary>Sets the callback invoked when insertion is canceled.</summary>
        public Object2InsertDirectHandlerBuilder OnCancel(Action<IDefinition, Object2InsertContext> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);
            _cancel = callback;
            return this;
        }

        /// <summary>Sets the callback invoked before the engine object is removed.</summary>
        public Object2InsertDirectHandlerBuilder OnRelease(Action<IDefinition, IEngineObject, Object2InsertContext> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);
            _release = callback;
            return this;
        }

        /// <summary>Builds the configured 2D object insert handler.</summary>
        public IObject2InsertHandler Build() => new ObjectInsertHandler(_objectsSource, _createObject, _createDefinition,
            _mode, _modeSelector, _attached, _drag, _complete, _cancel, _release);

        private sealed class ObjectInsertHandler : IObject2InsertHandler
        {
            private readonly IList<IEngineObject> _objectsSource;
            private readonly Func<IDefinition, IEngineObject> _createObject;
            private readonly Func<Object2InsertContext, IDefinition> _createDefinition;
            private readonly Object2InsertMode _defaultMode;
            private readonly Func<IDefinition, IEngineObject, Object2InsertMode>? _modeSelector;
            private readonly Action<IDefinition, IEngineObject, Object2InsertContext>? _attached;
            private readonly Action<IDefinition, Object2InsertContext>? _drag;
            private readonly Action<IDefinition, Object2InsertContext>? _complete;
            private readonly Action<IDefinition, Object2InsertContext>? _cancel;
            private readonly Action<IDefinition, IEngineObject, Object2InsertContext>? _release;
            private IDefinition? _activeDefinition;
            private IEngineObject? _activeObject;

            public ObjectInsertHandler(IList<IEngineObject> objectsSource, Func<IDefinition, IEngineObject> createObject,
                Func<Object2InsertContext, IDefinition> createDefinition, Object2InsertMode mode,
                Func<IDefinition, IEngineObject, Object2InsertMode>? modeSelector,
                Action<IDefinition, IEngineObject, Object2InsertContext>? attached,
                Action<IDefinition, Object2InsertContext>? drag, Action<IDefinition, Object2InsertContext>? complete,
                Action<IDefinition, Object2InsertContext>? cancel,
                Action<IDefinition, IEngineObject, Object2InsertContext>? release)
            {
                _objectsSource = objectsSource;
                _createObject = createObject;
                _createDefinition = createDefinition;
                _defaultMode = mode;
                _modeSelector = modeSelector;
                _attached = attached;
                _drag = drag;
                _complete = complete;
                _cancel = cancel;
                _release = release;
                Mode = mode;
            }

            public Object2InsertMode Mode { get; private set; }

            public IDefinition Create(Object2InsertContext context)
            {
                IDefinition definition = _createDefinition(context) ??
                    throw new InvalidOperationException("The create definition callback returned null.");
                IEngineObject obj = _createObject(definition) ??
                    throw new InvalidOperationException("The create object callback returned null.");
                _objectsSource.Add(obj);
                _activeDefinition = definition;
                _activeObject = obj;
                Mode = _modeSelector?.Invoke(definition, obj) ?? _defaultMode;
                _attached?.Invoke(definition, obj, context);
                return definition;
            }

            public void Drag(IDefinition definition, Object2InsertContext context) => _drag?.Invoke(definition, context);

            public void Complete(IDefinition definition, Object2InsertContext context)
            {
                _complete?.Invoke(definition, context);
                ClearActive(definition);
            }

            public void Cancel(IDefinition definition, Object2InsertContext context)
            {
                if (!ReferenceEquals(_activeDefinition, definition) || _activeObject is null)
                    throw new InvalidOperationException("The definition is not the active insertion definition.");
                IEngineObject obj = _activeObject;
                _cancel?.Invoke(definition, context);
                _release?.Invoke(definition, obj, context);
                _objectsSource.Remove(obj);
                ClearActive(definition);
            }

            private void ClearActive(IDefinition definition)
            {
                if (!ReferenceEquals(_activeDefinition, definition))
                    return;
                _activeDefinition = null;
                _activeObject = null;
                Mode = _defaultMode;
            }
        }
    }
}
