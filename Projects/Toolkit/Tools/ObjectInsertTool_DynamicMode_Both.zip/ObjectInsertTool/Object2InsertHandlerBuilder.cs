using System;

namespace Sachssoft.Engine.Components.Tools
{
    /// <summary>
    /// Provides a fluent builder for creating 2D object insert handlers.
    /// </summary>
    public sealed class Object2InsertHandlerBuilder
    {
        private readonly Func<Object2InsertContext, IDefinition> _create;
        private Object2InsertMode _mode = Object2InsertMode.Free;
        private Func<IDefinition, Object2InsertMode>? _modeSelector;
        private Action<IDefinition, Object2InsertContext>? _drag;
        private Action<IDefinition, Object2InsertContext>? _complete;
        private Action<IDefinition, Object2InsertContext>? _cancel;

        private Object2InsertHandlerBuilder(
            Func<Object2InsertContext, IDefinition> create)
        {
            _create = create;
        }

        /// <summary>
        /// Creates a new builder using the specified definition creation callback.
        /// </summary>
        /// <param name="callback">
        /// The callback used to create the definition when insertion begins.
        /// </param>
        /// <returns>
        /// A new builder instance.
        /// </returns>
        public static Object2InsertHandlerBuilder Create(
            Func<Object2InsertContext, IDefinition> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);

            return new Object2InsertHandlerBuilder(callback);
        }

        /// <summary>
        /// Sets the insertion mode.
        /// </summary>
        public Object2InsertHandlerBuilder WithMode(Object2InsertMode mode)
        {
            _mode = mode;
            _modeSelector = null;
            return this;
        }

        /// <summary>
        /// Sets a callback used to determine the insertion mode from the created definition.
        /// </summary>
        public Object2InsertHandlerBuilder WithMode(Func<IDefinition, Object2InsertMode> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);

            _modeSelector = callback;
            return this;
        }

        /// <summary>
        /// Sets the callback invoked while the definition is being dragged.
        /// </summary>
        /// <param name="callback">
        /// The callback invoked while the definition is being dragged.
        /// </param>
        /// <returns>
        /// This builder instance.
        /// </returns>
        public Object2InsertHandlerBuilder OnDrag(
            Action<IDefinition, Object2InsertContext> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);

            _drag = callback;
            return this;
        }

        /// <summary>
        /// Sets the callback invoked when insertion is completed.
        /// </summary>
        /// <param name="callback">
        /// The callback invoked when insertion is completed.
        /// </param>
        /// <returns>
        /// This builder instance.
        /// </returns>
        public Object2InsertHandlerBuilder OnComplete(
            Action<IDefinition, Object2InsertContext> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);

            _complete = callback;
            return this;
        }

        /// <summary>
        /// Sets the callback invoked when insertion is canceled.
        /// </summary>
        /// <param name="callback">
        /// The callback invoked when insertion is canceled.
        /// </param>
        /// <returns>
        /// This builder instance.
        /// </returns>
        public Object2InsertHandlerBuilder OnCancel(
            Action<IDefinition, Object2InsertContext> callback)
        {
            ArgumentNullException.ThrowIfNull(callback);

            _cancel = callback;
            return this;
        }

        /// <summary>
        /// Builds the configured 2D object insert handler.
        /// </summary>
        /// <returns>
        /// The configured object insert handler.
        /// </returns>
        public IObject2InsertHandler Build()
        {
            return new ObjectInsertHandler(
                _mode,
                _modeSelector,
                _create,
                _drag,
                _complete,
                _cancel);
        }

        private sealed class ObjectInsertHandler : IObject2InsertHandler
        {
            private readonly Object2InsertMode _defaultMode;
            private readonly Func<IDefinition, Object2InsertMode>? _modeSelector;
            private readonly Func<Object2InsertContext, IDefinition> _create;
            private readonly Action<IDefinition, Object2InsertContext>? _drag;
            private readonly Action<IDefinition, Object2InsertContext>? _complete;
            private readonly Action<IDefinition, Object2InsertContext>? _cancel;

            public ObjectInsertHandler(
                Object2InsertMode mode,
                Func<IDefinition, Object2InsertMode>? modeSelector,
                Func<Object2InsertContext, IDefinition> create,
                Action<IDefinition, Object2InsertContext>? drag,
                Action<IDefinition, Object2InsertContext>? complete,
                Action<IDefinition, Object2InsertContext>? cancel)
            {
                _defaultMode = mode;
                _modeSelector = modeSelector;
                Mode = mode;
                _create = create;
                _drag = drag;
                _complete = complete;
                _cancel = cancel;
            }

            public Object2InsertMode Mode { get; private set; }

            public IDefinition Create(Object2InsertContext context)
            {
                IDefinition definition = _create(context) ??
                    throw new InvalidOperationException("The create callback returned null.");

                Mode = _modeSelector?.Invoke(definition) ?? _defaultMode;
                return definition;
            }

            public void Drag(
                IDefinition definition,
                Object2InsertContext context)
            {
                _drag?.Invoke(
                    definition,
                    context);
            }

            public void Complete(
                IDefinition definition,
                Object2InsertContext context)
            {
                _complete?.Invoke(
                    definition,
                    context);
            }

            public void Cancel(
                IDefinition definition,
                Object2InsertContext context)
            {
                _cancel?.Invoke(
                    definition,
                    context);
            }
        }
    }
}