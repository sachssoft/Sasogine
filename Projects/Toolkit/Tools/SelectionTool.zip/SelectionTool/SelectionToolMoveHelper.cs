using Microsoft.Xna.Framework;
using Sachssoft.Sasogine.Common;
using System;
using System.Collections.Generic;

namespace Sachssoft.Sasogine.Components.Tools;

internal sealed class SelectionToolMoveHelper
{
    private Point2 _dragStartPosition;
    private Point2 _dragStartCursorPosition;
    private bool _isDragging;

    public SelectionToolMoveHelper()
    {
        Node = new SelectionToolNode(
            shape: SelectionToolNodeShape.Quad,
            isVisible: false,
            opacity: 0.3f);
    }

    public SelectionToolNode Node { get; }

    public void OnTargetInvalidated(
        SelectionToolLayerContext context,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition)
    {
        Node.Position = Point2.Zero;

        if (target != null)
        {
            Node.Size = target.Size;
            return;
        }

        if (definition != null)
        {
            Node.Size = definition.Size;
            return;
        }

        Node.Size = Size2.Zero;
    }

    public bool AllowHandle(
        SelectionToolNode node,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition)
    {
        if (!ReferenceEquals(node, Node))
            return false;

        return (target is ISelectionMovable2 movable &&
                movable.AllowMove) ||
               definition is ISelectionMovable2Definition;
    }

    public void OnNodeInteract(
        SelectionToolLayerContext context,
        SelectionToolNode node,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition,
        IEnumerable<ISelectionTarget2>? otherSelectedTargets,
        IEnumerable<ISelectionTarget2Definition>? otherSelectedTargetDefinitions,
        Point2 cursorPosition,
        Vector2 delta)
    {
        if (!ReferenceEquals(node, Node))
            return;

        Point2 currentPosition;

        if (target is ISelectionMovable2 movable &&
            movable.AllowMove)
        {
            currentPosition = movable.Position;
        }
        else if (definition is ISelectionMovable2Definition movableDefinition)
        {
            currentPosition = movableDefinition.Position;
        }
        else
        {
            return;
        }

        if (delta == Vector2.Zero)
        {
            _dragStartPosition = currentPosition;
            _dragStartCursorPosition = cursorPosition;
            _isDragging = true;
            return;
        }

        if (!_isDragging)
        {
            _dragStartPosition = currentPosition;
            _dragStartCursorPosition =
                cursorPosition - delta;

            _isDragging = true;
        }

        Vector2 dragOffset =
            cursorPosition -
            _dragStartCursorPosition;

        Point2 newPosition =
            _dragStartPosition +
            dragOffset;

        if (context.EnableGridSnap)
        {
            Size2 gridSize =
                context.GridSnapStep;

            if (gridSize.Width > 0f)
            {
                newPosition = new Point2(
                    MathF.Round(
                        newPosition.X /
                        gridSize.Width,
                        MidpointRounding.AwayFromZero) *
                    gridSize.Width,
                    newPosition.Y);
            }

            if (gridSize.Height > 0f)
            {
                newPosition = new Point2(
                    newPosition.X,
                    MathF.Round(
                        newPosition.Y /
                        gridSize.Height,
                        MidpointRounding.AwayFromZero) *
                    gridSize.Height);
            }
        }

        Vector2 movement =
            newPosition -
            currentPosition;

        if (movement == Vector2.Zero)
            return;

        if (target is ISelectionMovable2 movableTarget &&
            movableTarget.AllowMove)
        {
            if (target.Definition is not ISelectionMovable2Definition movableDefinition)
            {
                throw new InvalidOperationException(
                    $"The movable selection target requires an '{nameof(ISelectionMovable2Definition)}' definition.");
            }

            movableDefinition.Position += movement;
        }

        if (definition is ISelectionMovable2Definition movableDefinitionTarget)
        {
            movableDefinitionTarget.Position += movement;
        }

        if (otherSelectedTargets != null)
        {
            foreach (var otherTarget in otherSelectedTargets)
            {
                if (otherTarget is ISelectionMovable2 otherMovable &&
                    otherMovable.AllowMove)
                {
                    if (otherTarget.Definition is not ISelectionMovable2Definition otherDefinition)
                    {
                        throw new InvalidOperationException(
                            $"The movable selection target requires an '{nameof(ISelectionMovable2Definition)}' definition.");
                    }

                    otherDefinition.Position += movement;
                }
            }
        }

        if (otherSelectedTargetDefinitions != null)
        {
            foreach (var otherDefinition in otherSelectedTargetDefinitions)
            {
                if (otherDefinition is ISelectionMovable2Definition
                    otherMovableDefinition)
                {
                    otherMovableDefinition.Position += movement;
                }
            }
        }
    }
}
