using Microsoft.Xna.Framework;
using Sachssoft.Sasogine.Common;
using System;
using System.Collections.Generic;

namespace Sachssoft.Sasogine.Components.Tools;

/// <summary>
/// Provides a selection layer that allows selected targets to be moved,
/// resized, and rotated.
/// </summary>
public sealed class SelectionToolTransformLayer : SelectionToolLayer
{
    private readonly SelectionToolMoveHelper _move;
    private readonly SelectionToolResizeHelper _resize;
    private readonly SelectionToolRotationHelper _rotation;

    private Point2 _dragStartPosition;
    private Size2 _dragStartSize;
    private float _dragStartRotation;
    private Point2 _dragStartPivot;
    private bool _hasDragTransform;

    /// <summary>
    /// Initializes a new instance of the <see cref="SelectionToolTransformLayer"/> class.
    /// </summary>
    public SelectionToolTransformLayer()
    {
        _move = new SelectionToolMoveHelper();
        _resize = new SelectionToolResizeHelper();
        _rotation = new SelectionToolRotationHelper();

        Nodes.Add(_move.Node);

        foreach (var node in _resize.Nodes)
            Nodes.Add(node);

        foreach (var node in _rotation.Nodes)
            Nodes.Add(node);
    }

    /// <inheritdoc/>
    protected internal override void OnTargetInvalidated(
        SelectionToolLayerContext context,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition)
    {
        _move.OnTargetInvalidated(
            context,
            target,
            definition);

        _resize.OnTargetInvalidated(
            context,
            target,
            definition);

        _rotation.OnTargetInvalidated(
            context,
            target,
            definition);
    }

    /// <inheritdoc/>
    protected internal override bool AllowHandle(
        SelectionToolNode node,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition)
    {
        return _move.AllowHandle(
                   node,
                   target,
                   definition) ||
               _resize.AllowHandle(
                   node,
                   target,
                   definition) ||
               _rotation.AllowHandle(
                   node,
                   target,
                   definition);
    }

    /// <inheritdoc/>
    protected internal override void BeginNodeInteraction(
        SelectionToolLayerContext context,
        SelectionToolNode node,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition,
        Point2 cursorPosition)
    {
        CaptureDragTransform(target, definition);

        if (_move.AllowHandle(node, target, definition))
        {
            _move.BeginInteraction(node, target, definition, cursorPosition);
            return;
        }

        Point2 localCursorPosition = InverseDragTransform(cursorPosition);

        if (_resize.AllowHandle(node, target, definition))
        {
            _resize.BeginInteraction(node, target, definition, localCursorPosition);
            return;
        }

        if (_rotation.AllowHandle(node, target, definition))
            _rotation.BeginInteraction(node, target, definition, cursorPosition);
    }

    /// <inheritdoc/>
    protected internal override void EndNodeInteraction()
    {
        _move.EndInteraction();
        _resize.EndInteraction();
        _rotation.EndInteraction();
        _hasDragTransform = false;
    }

    /// <inheritdoc/>
    protected internal override void OnNodeInteract(
        SelectionToolLayerContext context,
        SelectionToolNode node,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition,
        IEnumerable<ISelectionTarget2>? otherSelectedTargets,
        IEnumerable<ISelectionTarget2Definition>? otherSelectedTargetDefinitions,
        Point2 cursorPosition,
        Vector2 delta)
    {
        if (_move.AllowHandle(
            node,
            target,
            definition))
        {
            _move.OnNodeInteract(
                context,
                node,
                target,
                definition,
                otherSelectedTargets,
                otherSelectedTargetDefinitions,
                cursorPosition);

            return;
        }

        if (!_hasDragTransform)
            return;

        Point2 localCursorPosition = InverseDragTransform(cursorPosition);

        if (_resize.AllowHandle(
            node,
            target,
            definition))
        {
            if (!_resize.OnNodeInteract(
                context,
                node,
                target,
                definition,
                localCursorPosition,
                out var originOffset,
                out var oldSize,
                out var newSize))
            {
                return;
            }

            Vector2 positionOffset = TransformResizeOffset(
                originOffset,
                oldSize,
                newSize,
                target,
                definition);

            ApplyPositionOffset(
                positionOffset,
                target,
                definition);

            return;
        }

        if (_rotation.AllowHandle(
            node,
            target,
            definition))
        {
            _rotation.OnNodeInteract(
                context,
                node,
                target,
                definition,
                cursorPosition,
                localCursorPosition);
        }
    }

    /// <inheritdoc/>
    protected internal override Point2 Transform(
        Point2 point,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition)
    {
        GetRotation(
            target,
            definition,
            out var size,
            out var rotation,
            out var pivot);

        Point2 pivotPosition = new Point2(
            size.Width * pivot.X,
            size.Height * pivot.Y);

        Vector2 relative =
            point -
            pivotPosition;

        float cos = MathF.Cos(rotation);
        float sin = MathF.Sin(rotation);

        Vector2 transformed = new Vector2(
            relative.X * cos - relative.Y * sin,
            relative.X * sin + relative.Y * cos);

        return pivotPosition + transformed;
    }

    /// <inheritdoc/>
    protected internal override Point2 InverseTransform(
        Point2 point,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition)
    {
        GetRotation(
            target,
            definition,
            out var size,
            out var rotation,
            out var pivot);

        Point2 pivotPosition = new Point2(
            size.Width * pivot.X,
            size.Height * pivot.Y);

        Vector2 relative =
            point -
            pivotPosition;

        float cos = MathF.Cos(rotation);
        float sin = MathF.Sin(rotation);

        Vector2 transformed = new Vector2(
            relative.X * cos + relative.Y * sin,
            -relative.X * sin + relative.Y * cos);

        return pivotPosition + transformed;
    }

    /// <inheritdoc/>
    protected internal override Vector2 TransformResizeOffset(
        Vector2 offset,
        Size2 oldSize,
        Size2 newSize,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition)
    {
        GetRotation(
            target,
            definition,
            out _,
            out var rotation,
            out var pivot);

        float cos = MathF.Cos(rotation);
        float sin = MathF.Sin(rotation);

        Vector2 Rotate(Vector2 value)
        {
            return new Vector2(
                value.X * cos - value.Y * sin,
                value.X * sin + value.Y * cos);
        }

        Vector2 oldPivot = new Vector2(
            oldSize.Width * pivot.X,
            oldSize.Height * pivot.Y);

        Vector2 newPivot = new Vector2(
            newSize.Width * pivot.X,
            newSize.Height * pivot.Y);

        Vector2 pivotDelta =
            oldPivot -
            newPivot;

        return Rotate(offset) +
               pivotDelta -
               Rotate(pivotDelta);
    }

    /// <inheritdoc/>
    protected internal override bool HitTestNode(
        Point2 position,
        SelectionToolNode node,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition,
        Point2 nodeWorldPosition)
    {
        if (!ReferenceEquals(node, _move.Node))
        {
            return base.HitTestNode(
                position,
                node,
                target,
                definition,
                nodeWorldPosition);
        }

        Point2 targetPosition = GetPosition(
            target,
            definition);

        Vector2 positionOffset =
            position -
            targetPosition;

        Point2 localPosition = InverseTransform(
            new Point2(positionOffset),
            target,
            definition);

        return localPosition.X >= node.Position.X &&
               localPosition.X <= node.Position.X + node.Size.Width &&
               localPosition.Y >= node.Position.Y &&
               localPosition.Y <= node.Position.Y + node.Size.Height;
    }

    private void CaptureDragTransform(
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition)
    {
        _dragStartPosition = GetPosition(
            target,
            definition);

        GetRotation(
            target,
            definition,
            out _dragStartSize,
            out _dragStartRotation,
            out _dragStartPivot);

        _hasDragTransform = true;
    }

    private Point2 InverseDragTransform(Point2 worldPosition)
    {
        Vector2 cursorOffset =
            worldPosition -
            _dragStartPosition;

        Point2 pivotPosition = new Point2(
            _dragStartSize.Width * _dragStartPivot.X,
            _dragStartSize.Height * _dragStartPivot.Y);

        Vector2 relative =
            cursorOffset -
            pivotPosition.ToVector2();

        float cos = MathF.Cos(_dragStartRotation);
        float sin = MathF.Sin(_dragStartRotation);

        Vector2 transformed = new Vector2(
            relative.X * cos + relative.Y * sin,
            -relative.X * sin + relative.Y * cos);

        return pivotPosition + transformed;
    }

    private static Point2 GetPosition(
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition)
    {
        if (definition is ISelectionMovable2Definition movableDefinition)
            return movableDefinition.Position;

        if (target is ISelectionMovable2 movable)
            return movable.Position;

        return Point2.Zero;
    }

    private static void GetRotation(
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition,
        out Size2 size,
        out float rotation,
        out Point2 pivot)
    {
        size = definition?.Size ?? target?.Size ?? Size2.Zero;
        rotation = 0f;
        pivot = new Point2(0.5f);

        if (definition is ISelectionRotatable2Definition rotatableDefinition)
        {
            rotation = rotatableDefinition.Rotation;
            pivot = rotatableDefinition.RotationPivot;
        }
        else if (target is ISelectionRotatable2 rotatable)
        {
            rotation = rotatable.Rotation;
            pivot = rotatable.RotationPivot;
        }
    }

    private static void ApplyPositionOffset(
        Vector2 offset,
        ISelectionTarget2? target,
        ISelectionTarget2Definition? definition)
    {
        if (definition is ISelectionMovable2Definition definitionMovable)
        {
            definitionMovable.Position += offset;
            return;
        }

        if (target is ISelectionMovable2 movable && movable.AllowMove)
        {
            if (target.Definition is not ISelectionMovable2Definition movableDefinition)
                throw new InvalidOperationException($"The movable selection target requires an '{nameof(ISelectionMovable2Definition)}' definition.");

            movableDefinition.Position += offset;
        }
    }
}
