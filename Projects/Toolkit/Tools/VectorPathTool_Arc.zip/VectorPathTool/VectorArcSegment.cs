using Sachssoft.Engine.Geometry;
using System;

namespace Sachssoft.Engine.Components.Tools;

/// <summary>
/// Represents an axis-aligned elliptical arc segment passing through two control points.
/// </summary>
/// <remarks>
/// The start point, both control points, and the endpoint define an axis-aligned ellipse.
/// The control points also determine which ordered portion of the ellipse is used.
/// </remarks>
public sealed class VectorArcSegment : VectorFixedSegment<VectorArcSegmentDefinition>
{
    private const float Epsilon = 0.000001f;

    private Point2 _startPositionCache;
    private Point2 _controlPosition0Cache;
    private Point2 _controlPosition1Cache;
    private Point2 _endPositionCache;
    private float _sampleLengthCache;
    private Point2[]? _sampledVerticesCache;

    /// <summary>
    /// Initializes a new instance of the <see cref="VectorArcSegment"/> class.
    /// </summary>
    public VectorArcSegment() : this(CreateDefinition())
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="VectorArcSegment"/> class.
    /// </summary>
    public VectorArcSegment(Point2 position, Point2 controlPosition0, Point2 controlPosition1)
        : this(position, controlPosition0, controlPosition1, false)
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="VectorArcSegment"/> class.
    /// </summary>
    public VectorArcSegment(Point2 position, Point2 controlPosition0, Point2 controlPosition1, bool isSelected)
        : this(CreateDefinition(position, controlPosition0, controlPosition1, isSelected))
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="VectorArcSegment"/> class using the specified definition.
    /// </summary>
    public VectorArcSegment(VectorArcSegmentDefinition definition) : base(controlCount: 2, definition)
    {
    }

    /// <inheritdoc/>
    protected override VectorNode CreateVectorNode(int index, VectorArcSegmentDefinition definition)
    {
        return index switch
        {
            0 => new VectorNode(definition.ControlNode0),
            1 => new VectorNode(definition.ControlNode1),
            _ => throw new ArgumentOutOfRangeException(nameof(index))
        };
    }

    /// <inheritdoc/>
    public override Point2[] GetVertices(Point2 startPosition, float sampleLength)
    {
        if (sampleLength <= 0f)
            throw new ArgumentOutOfRangeException(nameof(sampleLength));

        Point2 controlPosition0 = GetControlNodes()[0].Position;
        Point2 controlPosition1 = GetControlNodes()[1].Position;
        Point2 endPosition = Node.Position;

        if (_sampledVerticesCache != null &&
            _startPositionCache == startPosition &&
            _controlPosition0Cache == controlPosition0 &&
            _controlPosition1Cache == controlPosition1 &&
            _endPositionCache == endPosition &&
            _sampleLengthCache == sampleLength)
        {
            return _sampledVerticesCache;
        }

        _startPositionCache = startPosition;
        _controlPosition0Cache = controlPosition0;
        _controlPosition1Cache = controlPosition1;
        _endPositionCache = endPosition;
        _sampleLengthCache = sampleLength;

        if (!TryCalculateArc(startPosition, controlPosition0, controlPosition1, endPosition,
            out float radiusX, out float radiusY, out float sweepAngle))
        {
            _sampledVerticesCache = [startPosition, endPosition];
            return _sampledVerticesCache;
        }

        bool sweep = sweepAngle > 0f;
        bool largeArc = MathF.Abs(sweepAngle) > MathF.PI;
        int segmentCount = CalculateArcSegments(radiusX, radiusY, sweepAngle, sampleLength);

        _sampledVerticesCache = GeometrySampler.SampleArc(
            startPosition,
            endPosition,
            radiusX,
            radiusY,
            0f,
            largeArc,
            sweep,
            segmentCount);

        return _sampledVerticesCache;
    }

    private static VectorArcSegmentDefinition CreateDefinition()
    {
        return new VectorArcSegmentDefinition();
    }

    private static VectorArcSegmentDefinition CreateDefinition(
        Point2 position,
        Point2 controlPosition0,
        Point2 controlPosition1,
        bool isSelected)
    {
        var definition = new VectorArcSegmentDefinition();
        definition.Node.Position = position;
        definition.Node.IsSelected = isSelected;
        definition.ControlNode0.Position = controlPosition0;
        definition.ControlNode1.Position = controlPosition1;
        return definition;
    }

    private static bool TryCalculateArc(
        Point2 start,
        Point2 control0,
        Point2 control1,
        Point2 end,
        out float radiusX,
        out float radiusY,
        out float sweepAngle)
    {
        radiusX = 0f;
        radiusY = 0f;
        sweepAngle = 0f;

        Point2[] points = [start, control0, control1, end];
        double[,] matrix = new double[4, 5];

        for (int row = 0; row < 4; row++)
        {
            double x = points[row].X;
            double y = points[row].Y;
            matrix[row, 0] = x * x;
            matrix[row, 1] = y * y;
            matrix[row, 2] = x;
            matrix[row, 3] = y;
            matrix[row, 4] = 1d;
        }

        double[] coefficients = new double[5];
        for (int column = 0; column < 5; column++)
            coefficients[column] = ((column & 1) == 0 ? 1d : -1d) * MinorDeterminant(matrix, column);

        double a = coefficients[0];
        double b = coefficients[1];
        double c = coefficients[2];
        double d = coefficients[3];
        double e = coefficients[4];

        double scale = Math.Max(Math.Abs(a), Math.Abs(b));
        if (scale <= Epsilon || a * b <= 0d)
            return false;

        a /= scale;
        b /= scale;
        c /= scale;
        d /= scale;
        e /= scale;

        double centerX = -c / (2d * a);
        double centerY = -d / (2d * b);
        double translatedConstant = e - a * centerX * centerX - b * centerY * centerY;
        double radiusXSquared = -translatedConstant / a;
        double radiusYSquared = -translatedConstant / b;

        if (radiusXSquared <= Epsilon || radiusYSquared <= Epsilon)
            return false;

        radiusX = (float)Math.Sqrt(radiusXSquared);
        radiusY = (float)Math.Sqrt(radiusYSquared);

        float startAngle = GetEllipseAngle(start, centerX, centerY, radiusX, radiusY);
        float controlAngle0 = GetEllipseAngle(control0, centerX, centerY, radiusX, radiusY);
        float controlAngle1 = GetEllipseAngle(control1, centerX, centerY, radiusX, radiusY);
        float endAngle = GetEllipseAngle(end, centerX, centerY, radiusX, radiusY);

        float ccw0 = NormalizePositiveAngle(controlAngle0 - startAngle);
        float ccw1 = NormalizePositiveAngle(controlAngle1 - startAngle);
        float ccwEnd = NormalizePositiveAngle(endAngle - startAngle);

        if (ccw0 <= ccw1 + Epsilon && ccw1 <= ccwEnd + Epsilon)
        {
            sweepAngle = ccwEnd;
        }
        else
        {
            float cw0 = NormalizePositiveAngle(startAngle - controlAngle0);
            float cw1 = NormalizePositiveAngle(startAngle - controlAngle1);
            float cwEnd = NormalizePositiveAngle(startAngle - endAngle);

            if (cw0 <= cw1 + Epsilon && cw1 <= cwEnd + Epsilon)
                sweepAngle = -cwEnd;
            else
                return false;
        }

        return MathF.Abs(sweepAngle) > Epsilon;
    }

    private static float GetEllipseAngle(Point2 point, double centerX, double centerY, float radiusX, float radiusY)
    {
        return MathF.Atan2(
            (float)((point.Y - centerY) / radiusY),
            (float)((point.X - centerX) / radiusX));
    }

    private static int CalculateArcSegments(float radiusX, float radiusY, float sweepAngle, float sampleLength)
    {
        float h = MathF.Pow(radiusX - radiusY, 2f) / MathF.Pow(radiusX + radiusY, 2f);
        float circumference = MathF.PI * (radiusX + radiusY) * (1f + 3f * h / (10f + MathF.Sqrt(4f - 3f * h)));
        float arcLength = circumference * MathF.Abs(sweepAngle) / MathF.Tau;
        return Math.Max(1, (int)MathF.Ceiling(arcLength / sampleLength));
    }

    private static double MinorDeterminant(double[,] matrix, int excludedColumn)
    {
        double[,] minor = new double[4, 4];
        for (int row = 0; row < 4; row++)
        {
            int targetColumn = 0;
            for (int column = 0; column < 5; column++)
            {
                if (column == excludedColumn)
                    continue;
                minor[row, targetColumn++] = matrix[row, column];
            }
        }
        return Determinant4(minor);
    }

    private static double Determinant4(double[,] m)
    {
        double result = 0d;
        for (int column = 0; column < 4; column++)
        {
            double[,] minor = new double[3, 3];
            for (int row = 1; row < 4; row++)
            {
                int targetColumn = 0;
                for (int sourceColumn = 0; sourceColumn < 4; sourceColumn++)
                {
                    if (sourceColumn == column)
                        continue;
                    minor[row - 1, targetColumn++] = m[row, sourceColumn];
                }
            }
            result += ((column & 1) == 0 ? 1d : -1d) * m[0, column] * Determinant3(minor);
        }
        return result;
    }

    private static double Determinant3(double[,] m)
    {
        return
            m[0, 0] * (m[1, 1] * m[2, 2] - m[1, 2] * m[2, 1]) -
            m[0, 1] * (m[1, 0] * m[2, 2] - m[1, 2] * m[2, 0]) +
            m[0, 2] * (m[1, 0] * m[2, 1] - m[1, 1] * m[2, 0]);
    }

    private static float NormalizePositiveAngle(float angle)
    {
        angle %= MathF.Tau;
        if (angle < 0f)
            angle += MathF.Tau;
        return angle;
    }
}
