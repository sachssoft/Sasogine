﻿using Sachssoft.Sasodoc;
using System.Collections.Generic;
using Sachssoft.Sasogine.Documents.Serialization;

namespace Sachssoft.Sasogine.Components.Tools.Vector;

public sealed class VectorShapeSerialization : SerializationBase<VectorShapeDefinition>
{
    private readonly VectorPathSerialization _pathSerialization;

    public VectorShapeSerialization()
        : this(new VectorSegmentSerializationRegistry())
    {
    }

    public VectorShapeSerialization(VectorSegmentSerializationRegistry? segmentRegistry)
    {
        _pathSerialization = new VectorPathSerialization(segmentRegistry);
    }

    public override void Deserialize(VectorShapeDefinition target, FormatReaderBase reader)
    {
        target.IsLocked = reader.ReadBoolean(nameof(VectorShapeDefinition.IsLocked), target.IsLocked);

        if (reader.Contains(nameof(VectorShapeDefinition.Paths)))
        {
            var pathReaders = reader.ReadArray(nameof(VectorShapeDefinition.Paths));
            target.Paths.Clear();
            foreach (var pathReader in pathReaders)
            {
                var path = new VectorPathDefinition();
                _pathSerialization.Deserialize(path, pathReader);
                target.Paths.Add(path);
            }
        }
    }

    public override void Serialize(VectorShapeDefinition source, FormatWriterBase writer)
    {
        writer.WriteBoolean(nameof(VectorShapeDefinition.IsLocked), source.IsLocked);

        var pathWriters = new List<FormatWriterBase>();
        foreach (var path in source.Paths)
        {
            var pathWriter = writer.CreateWriter();
            _pathSerialization.Serialize(path, pathWriter);
            pathWriters.Add(pathWriter);
        }
        writer.WriteArray(nameof(VectorShapeDefinition.Paths), pathWriters.ToArray());
    }
}
