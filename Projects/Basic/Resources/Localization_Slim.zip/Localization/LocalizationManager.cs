using System;
using System.Collections.Generic;
using System.Globalization;

namespace Sachssoft.Sasogine.Resources.Localization;

/// <summary>
/// Manages localized strings and assets for the active culture.
/// </summary>
public sealed class LocalizationManager
{
    private readonly Dictionary<string, CultureEntry> _cultures =
        new(StringComparer.OrdinalIgnoreCase);

    private readonly GameApplicationBase _application;
    private readonly LocalizedDictionary _emptyDictionary = new();

    private CultureInfo _culture = CultureInfo.InvariantCulture;

    private sealed class CultureEntry
    {
        public CultureEntry(
            LocalizedDictionary dictionary,
            AssetStore assets)
        {
            Dictionary = dictionary;
            Assets = assets;
        }

        public LocalizedDictionary Dictionary { get; }

        public AssetStore Assets { get; }
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="LocalizationManager"/> class.
    /// </summary>
    public LocalizationManager(GameApplicationBase application)
    {
        ArgumentNullException.ThrowIfNull(application);
        _application = application;
    }

    /// <summary>
    /// Occurs when the active localization culture changes.
    /// </summary>
    public event EventHandler? CultureChanged;

    /// <summary>
    /// Gets or sets the culture used for localization.
    /// </summary>
    public CultureInfo Culture
    {
        get => _culture;
        set
        {
            ArgumentNullException.ThrowIfNull(value);

            if (_culture.Equals(value))
                return;

            _culture = value;
            CultureChanged?.Invoke(this, EventArgs.Empty);
        }
    }

    /// <summary>
    /// Gets the localized string dictionary for the active culture.
    /// </summary>
    public LocalizedDictionary Entries =>
        TryGetCurrentEntry(out CultureEntry? entry)
            ? entry.Dictionary
            : _emptyDictionary;

    /// <summary>
    /// Gets the localized asset store for the active culture.
    /// </summary>
    /// <exception cref="InvalidOperationException">
    /// Thrown when no localization data is registered for the active culture.
    /// </exception>
    public AssetStore Assets =>
        TryGetCurrentEntry(out CultureEntry? entry)
            ? entry.Assets
            : throw new InvalidOperationException(
                $"No localized assets are registered for culture '{_culture.Name}'.");

    /// <summary>
    /// Adds localization data for the specified culture.
    /// </summary>
    public void Add(
        CultureInfo culture,
        LocalizedDictionary dictionary,
        AssetStore assets)
    {
        ArgumentNullException.ThrowIfNull(culture);
        ArgumentNullException.ThrowIfNull(dictionary);
        ArgumentNullException.ThrowIfNull(assets);

        _cultures[culture.Name] = new CultureEntry(dictionary, assets);
    }

    /// <summary>
    /// Determines whether localization data exists for the specified culture.
    /// </summary>
    public bool Contains(CultureInfo culture)
    {
        ArgumentNullException.ThrowIfNull(culture);
        return _cultures.ContainsKey(culture.Name);
    }

    /// <summary>
    /// Closes all localized string dictionaries.
    /// </summary>
    public void Close()
    {
        foreach (CultureEntry entry in _cultures.Values)
            entry.Dictionary.Close();
    }

    private bool TryGetCurrentEntry(out CultureEntry? entry)
    {
        return _cultures.TryGetValue(_culture.Name, out entry);
    }
}
