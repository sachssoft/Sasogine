# Localization

Simplified localization architecture:

- `LocalizedDictionary` stores localized strings and plural variants only.
- `LocalizationManager` owns the active `CultureInfo`.
- Each registered culture has both a `LocalizedDictionary` and an `AssetStore`.
- Localized assets are stored directly in the culture-specific `AssetStore`.
- `LocalizedResource`, `ILocalizedEntry`, `LocalizedTypeRegistry`, and `LocalizedEntryData` are no longer required.
- Changing `LocalizationManager.Culture` does not modify the global .NET culture.
