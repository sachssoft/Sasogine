using System;

namespace Sachssoft.Sasogine.Resources.Localization;

/// <summary>
/// Binds a localized string to a setter and updates it when the culture changes.
/// </summary>
public sealed class LocalizationBinding : IDisposable
{
    private readonly GameApplicationBase _application;
    private readonly string _key;
    private readonly string? _defaultValue;
    private readonly Action<string?> _setter;
    private bool _disposed;

    internal LocalizationBinding(
        GameApplicationBase application,
        string key,
        string? defaultValue,
        Action<string?> setter)
    {
        ArgumentNullException.ThrowIfNull(application);
        ArgumentException.ThrowIfNullOrEmpty(key);
        ArgumentNullException.ThrowIfNull(setter);

        _application = application;
        _key = key;
        _defaultValue = defaultValue;
        _setter = setter;

        _application.Localization.CultureChanged += OnCultureChanged;
        UpdateValue();
    }

    /// <inheritdoc/>
    public void Dispose()
    {
        if (_disposed)
            return;

        _application.Localization.CultureChanged -= OnCultureChanged;
        _disposed = true;
    }

    private void OnCultureChanged(object? sender, EventArgs e)
    {
        UpdateValue();
    }

    private void UpdateValue()
    {
        if (_disposed)
            return;

        _setter(
            _application.Localization.Entries.GetValue(
                _key,
                _defaultValue));
    }
}
