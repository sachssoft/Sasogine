﻿namespace Sachssoft.Sasogine.Components.Rendering.Animation.Timings;

public sealed class EaseLinear : EasingBase
{
    public override float GetValue(float percent) => percent;
}
