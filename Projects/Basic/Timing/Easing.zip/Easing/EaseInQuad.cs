﻿namespace Sachssoft.Sasogine.Components.Rendering.Animation.Timings;

public sealed class EaseInQuad : EasingBase
{
    public override float GetValue(float percent) => percent * percent;
}
