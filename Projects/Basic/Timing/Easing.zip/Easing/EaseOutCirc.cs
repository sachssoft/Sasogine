﻿namespace Sachssoft.Sasogine.Components.Rendering.Animation.Timings;

public sealed class EaseOutCirc : EasingBase
{
    public override float GetValue(float percent)
    {
        percent--;
        return float.Sqrt(1 - percent * percent);
    }
}