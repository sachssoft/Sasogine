﻿using System;

namespace Sachssoft.Sasogine.Components.Rendering.Animation.Timings;

public sealed class EaseInElastic : EasingBase
{
    public override float GetValue(float percent)
    {
        if (percent == 0 || percent == 1) return percent;
        return -float.Pow(2, 10 * (percent - 1)) * float.Sin((percent - 1.075f) * (2 * MathF.PI) / 0.3f);
    }
}