﻿namespace Sachssoft.Sasogine.Components.Rendering.Animation.Timings;

public sealed class EaseOutQuad : EasingBase
{
    public override float GetValue(float percent) => percent * (2 - percent);
}
