﻿namespace Sachssoft.Sasogine.Components.Rendering.Animation.Timings;

public sealed class EaseInSine : EasingBase
{
    public override float GetValue(float percent) =>
        (float)(1 - float.Cos(percent * float.Pi / 2));
}
