﻿namespace Sachssoft.Sasogine.Components.Rendering.Animation.Timings;

public sealed class EaseOutQuint : EasingBase
{
    public override float GetValue(float percent)
    {
        percent--;
        return 1 + percent * percent * percent * percent * percent;
    }
}