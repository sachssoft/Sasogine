﻿namespace Sachssoft.Sasogine.Components.Rendering.Animation.Timings;

public sealed class EaseInBounce : EasingBase
{
    private readonly EaseOutBounce _out = new();

    public override float GetValue(float percent) =>
        1 - _out.GetValue(1 - percent);
}