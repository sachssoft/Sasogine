﻿namespace Sachssoft.Sasogine.Components.Rendering.Animation.Timings;

public sealed class EaseOutQuart : EasingBase
{
    public override float GetValue(float percent)
    {
        percent--;
        return 1 - (percent * percent * percent * percent);
    }
}