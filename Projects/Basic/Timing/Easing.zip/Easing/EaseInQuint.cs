﻿namespace Sachssoft.Sasogine.Components.Rendering.Animation.Timings;

public sealed class EaseInQuint : EasingBase
{
    public override float GetValue(float percent) => percent * percent * percent * percent * percent;
}
