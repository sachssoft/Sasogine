﻿using Microsoft.Xna.Framework;
using Sachssoft.Sasogine.Common;

namespace Sachssoft.Sasogine.Components.Rendering;

/// <summary>
/// Defines an animation component that contributes position and rotation changes
/// to an animatable object.
/// </summary>
public interface IAnimationComponent
{
    /// <summary>
    /// Calculates the current position offset contributed by the animation.
    /// </summary>
    /// <param name="elapsedTime">The elapsed time since the previous update, in seconds.</param>
    /// <returns>The position offset contributed by the animation.</returns>
    Vector2 AddPosition(float elapsedTime);

    /// <summary>
    /// Calculates the current rotation offset contributed by the animation.
    /// </summary>
    /// <param name="elapsedTime">The elapsed time since the previous update, in seconds.</param>
    /// <returns>The rotation offset contributed by the animation, in degrees.</returns>
    float AddRotation(float elapsedTime);

    /// <summary>
    /// Starts the animation using the specified initial position and rotation.
    /// </summary>
    /// <param name="position">The initial position of the animated object.</param>
    /// <param name="rotation">The initial rotation of the animated object, in degrees.</param>
    void Start(Point2 position, float rotation);

    /// <summary>
    /// Toggles the paused state of the animation.
    /// </summary>
    void Pause();

    /// <summary>
    /// Resets the animation timer and its internal animation state.
    /// </summary>
    void Reset();
}
