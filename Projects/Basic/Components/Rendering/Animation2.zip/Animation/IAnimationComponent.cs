﻿using Microsoft.Xna.Framework;
using Sachssoft.Sasogine.Common;

namespace Sachssoft.Sasogine.Components.Rendering;

public interface IAnimationComponent
{
    Point2 AddPosition(float elapsedTime);

    float AddRotation(float elapsedTime);

    void Start(Point2 position, float rotation);

    void Pause();

    void Reset();
}
