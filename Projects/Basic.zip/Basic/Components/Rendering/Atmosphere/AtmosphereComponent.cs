﻿using Sachssoft.Engine.Scenes;

namespace Sachssoft.Engine.Components.Rendering
{
    /// <summary>
    /// Provides an atmosphere rendering component that manages atmospheric
    /// effects and participates in scene updates and rendering.
    ///
    /// The component is designed to combine multiple visual atmosphere effects
    /// through shader-based rendering while minimizing render target switches.
    /// </summary>
    public class AtmosphereComponent : ResourceComponentBase, IUpdatableComponent, IDrawableComponent
    {
        // Mehrere RenderTargets sollten möglichst vermieden werden,
        // da jeder RenderTarget-Wechsel zusätzlichen GPU-Overhead verursacht
        // (State Changes, Memory Bandwidth und Pipeline Flushes).
        //
        // Außerdem steigt der Speicherverbrauch stark an,
        // da jedes RenderTarget (z.B. 1920x1080 RGBA) mehrere MB VRAM benötigt.
        //
        // Statt viele separate RenderTargets für einzelne Effekte zu verwenden,
        // wird die Szene in EIN einheitliches RenderTarget gerendert.
        //
        // Mehrere visuelle Effekte (z.B. Fog, Underwater, HeatHaze, ColorGrading)
        // sollten anschließend in einem oder wenigen Fullscreen-Shader-Pässen
        // kombiniert werden, da Shader auf der GPU parallel pro Pixel arbeiten
        // und dadurch deutlich effizienter sind als mehrere Render-Pässe.
        //
        // Ziel: minimale RenderTarget-Anzahl, maximale Nutzung von Shadern.

        /// <summary>
        /// Initializes a new instance of the <see cref="AtmosphereComponent"/> class
        /// using a default atmosphere definition.
        /// </summary>
        public AtmosphereComponent()
        {
        }


        /// <summary>
        /// Gets or sets whether the atmosphere component participates in updates.
        /// </summary>
        public bool IsEnabled { get; set; } = true;


        /// <summary>
        /// Gets or sets whether the atmosphere component is rendered.
        /// </summary>
        public bool IsVisible { get; set; } = true;
    }
}