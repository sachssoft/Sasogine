﻿using Sachssoft.Engine;

namespace Sachssoft.Engine.Graphics.Rendering;

/// <summary>
/// Defines a read-only 2D transform that provides a rotation pivot.
/// </summary>
public interface IReadOnlyRotationPivot2 : IReadOnlyTransformRotationPivot2
{
    /// <summary>
    /// Gets a value indicating whether modifying the rotation pivot is allowed.
    /// </summary>
    bool AllowRotationPivot { get; }
}