﻿namespace Sachssoft.Engine.Packages
{
    /// <summary>
    /// Defines an object that provides access to package storage.
    /// </summary>
    public interface IPackageStorageProvider
    {
        /// <summary>
        /// Gets the package storage.
        /// </summary>
        IPackageStorage Storage { get; }
    }
}