﻿using Sachssoft.Engine;
using System;

namespace Sachssoft.Engine.Packages
{
    /// <summary>
    /// Defines the common metadata of a package.
    /// </summary>
    public interface IPackageDefinition : IEngineObjectDefinition
    {
        /// <summary>
        /// Gets or sets the version of the package.
        /// </summary>
        Version? Version { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the user associated with the package.
        /// </summary>
        Guid UserId { get; set; }

        /// <summary>
        /// Gets or sets the name of the package creator.
        /// </summary>
        string? CreatorName { get; set; }

        /// <summary>
        /// Gets or sets the email address of the package creator.
        /// </summary>
        string? CreatorEmail { get; set; }

        /// <summary>
        /// Gets or sets the license that defines how the package may be used
        /// and modified.
        /// </summary>
        PackageLicense License { get; set; }
    }
}