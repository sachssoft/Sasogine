﻿using Sachssoft.Engine.Assets;

namespace Sachssoft.Engine.Packages;

/// <summary>
/// Defines storage that can synchronize package assets.
/// </summary>
public interface IPackageAssetStorage
{
    /// <summary>
    /// Synchronizes the package assets.
    /// </summary>
    /// <param name="resolver">
    /// The asset resolver to use, or <see langword="null"/>
    /// to use the default resolution behavior.
    /// </param>
    void SynchronizeAssets(
        AssetResolver? resolver = null);
}