using Sachssoft.Engine.Assets;
using Sachssoft.Engine.Resources;

namespace Sachssoft.Engine.Packages
{
    /// <summary>
    /// Defines storage that provides resource loaders for package assets.
    /// </summary>
    public interface IPackageStorage
    {
        /// <summary>
        /// Gets the resource loader for the specified asset file.
        /// </summary>
        /// <param name="assetFile">
        /// The asset file for which to get the resource loader.
        /// </param>
        /// <returns>
        /// The resource loader associated with the asset file.
        /// </returns>
        ResourceSourceBase GetLoader(IAssetFile assetFile);
    }
}