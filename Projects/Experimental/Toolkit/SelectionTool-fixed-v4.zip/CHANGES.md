# Changes

## Experimental namespace

- Moved SelectionTool implementation namespaces to `Sachssoft.Sasogine.Experimental.Components.Tools` and `.Selection`.
- Existing selection target/capability interfaces remain referenced from `Sachssoft.Sasogine.Components.Tools.Selection`.

## Transform lifecycle

- Added `IsTransforming`.
- Added `TransformStarted` and `TransformCompleted` events.
- Added `ConsumeTransformCompleted()` for polling-based integrations.
- Transform completion is now also handled when the pointer is released outside the viewport.
- Cancellation clears the active transform state without reporting a completed transform.

## Drag and snapping fixes

- Fixed first-drag behavior so clicking an unselected movable target can select and begin dragging in the same interaction.
- Move dragging now derives position from the drag-start position and absolute cursor displacement for both snapped and unsnapped movement, avoiding accumulated drift.
- Grid, angle, and pivot midpoint snapping now use deterministic `MidpointRounding.AwayFromZero`.

## Transform notifications and namespace fixes

- Added the missing `Sachssoft.Sasogine.Components.Tools.Toolbase` import required by `SelectionTool : ToolBase`.
- Added optional `INotifyTransformChanged` target notifications with start, change, and complete callbacks.
- Added the `TransformChanged` tool event alongside `TransformStarted` and `TransformCompleted`.
- Kept `IsTransforming` and `ConsumeTransformCompleted()` for polling-based integrations.
- Experimental SelectionTool implementation remains under `Sachssoft.Sasogine.Experimental.Components.Tools` / `.Selection`; existing selection target capability interfaces remain under `Sachssoft.Sasogine.Components.Tools.Selection`.

## Rotation drag stability

- Moved `INotifyTransformChanged` to `Sachssoft.Sasogine.Common`.
- Fixed rotation dragging across the `Atan2` `-PI`/`+PI` boundary.
- Rotation now accumulates normalized per-update angle deltas instead of recomputing the full angle from the drag start.
- Angle snapping is applied only to the accumulated output rotation, while the unsnapped accumulated rotation remains continuous.
