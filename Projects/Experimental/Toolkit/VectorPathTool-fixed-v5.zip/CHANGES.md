
## Shape locking

- Removed `VectorPath.IsLocked` and `VectorPath.IsSelected`.
- Added `VectorShape.IsLocked` as the single geometry editing lock.
- Kept `VectorNode.IsSelected` for node-level selection.
- Updated `VectorPathTool` lock checks to resolve the owning shape instead of individual paths.
