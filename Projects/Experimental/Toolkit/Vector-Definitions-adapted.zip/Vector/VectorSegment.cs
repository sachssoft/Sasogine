using Sachssoft.Sasogine.Common;
using System.Collections.Generic;

namespace Sachssoft.Sasogine.Experimental.Components.Tools.Vector
{
    /// <summary>
    /// Represents the base class for a vector path segment.
    /// </summary>
    public abstract class VectorSegment : EngineObject<VectorSegmentDefinition>, IVectorSegment, IVectorSegmentInternal
    {
        private VectorPath? _path;

        /// <summary>
        /// Initializes a new instance of the <see cref="VectorSegment"/> class.
        /// </summary>
        protected VectorSegment(VectorSegmentDefinition definition)
            : base(definition)
        {
            Node = new VectorNode(definition.Node) { Segment = this };
        }

        /// <summary>
        /// Gets the vector path that owns this segment.
        /// </summary>
        public VectorPath? Path => _path;

        VectorPath? IVectorSegmentInternal.Path
        {
            get => _path;
            set => _path = value;
        }

        /// <summary>
        /// Gets the endpoint node of the vector segment.
        /// </summary>
        public VectorNode Node { get; }

        /// <inheritdoc/>
        protected override void ConfigureFromDefinition()
        {
            base.ConfigureFromDefinition();
            Node.Reload();
        }

        public abstract IReadOnlyList<VectorNode> GetControlNodes();
        public abstract Point2[] GetVertices(Point2 startPosition, float sampleLength);
    }
}
