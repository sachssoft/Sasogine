using Sachssoft.Sasogine.Common;

namespace Sachssoft.Sasogine.Experimental.Components.Tools.Vector
{
    public sealed class VectorNodeDefinition : IDefinition
    {

        public Point2 Position { get; set; }

        public bool IsSelected { get; set; }

    }
}