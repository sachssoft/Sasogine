using Sachssoft.Sasogine.Common;

namespace Sachssoft.Sasogine.Experimental.Components.Tools.Vector
{
    /// <summary>
    /// Represents a node in a vector path.
    /// </summary>
    public sealed class VectorNode : EngineObject<VectorNodeDefinition>
    {
        private Point2 _position;
        private bool _isSelected;

        /// <summary>
        /// Initializes a new instance of the <see cref="VectorNode"/> class.
        /// </summary>
        public VectorNode() : base(new VectorNodeDefinition())
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="VectorNode"/> class
        /// at the specified position.
        /// </summary>
        /// <param name="position">
        /// The initial position of the node.
        /// </param>
        public VectorNode(
            Point2 position) : base(new VectorNodeDefinition
            {
                Position = position
            })
        {
            
        }

        protected override void ConfigureFromDefinition()
        {
            base.ConfigureFromDefinition();
            _position = Definition.Position;
            _isSelected = Definition.IsSelected;
        }

        /// <summary>
        /// Gets the vector segment that owns this node.
        /// </summary>
        public VectorSegment? Segment { get; internal set; }

        /// <summary>
        /// Gets or sets the position of the node.
        /// </summary>
        public Point2 Position => _position;

        /// <summary>
        /// Gets or sets whether the node is selected.
        /// </summary>
        public bool IsSelected => _isSelected;
    }
}