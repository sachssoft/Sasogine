using Microsoft.Xna.Framework;
using Sachssoft.Sasogine.Common;
using System;
using System.Collections.Generic;

namespace Sachssoft.Sasogine.Experimental.Components.Tools.Vector
{
    /// <summary>
    /// Represents a vector shape containing a collection of vector paths.
    /// </summary>
    public class VectorShape
    {
        private const float DefaultSampleLength = 4f;

        private readonly ITransform2? _source;
        private readonly Transform2State? _transformState;

        /// <summary>
        /// Initializes a new instance of the <see cref="VectorShape"/> class.
        /// </summary>
        public VectorShape()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="VectorShape"/> class
        /// using the specified transform source.
        /// </summary>
        /// <param name="source">
        /// The transform source used by the shape.
        /// </param>
        public VectorShape(ITransform2? source)
        {
            _source = source;

            if (source != null)
                _transformState = new Transform2State(source);
        }

        /// <summary>
        /// Gets the vector paths that define the shape.
        /// </summary>
        public List<VectorPath> Paths { get; } = [];

        /// <summary>
        /// Gets the transform source associated with the shape.
        /// </summary>
        public ITransform2? TransformSource => _source;

        /// <summary>
        /// Gets the sampled point vertices of all vector paths.
        /// </summary>
        /// <param name="valueMode">
        /// Specifies whether the returned vertices use absolute or relative coordinates.
        /// </param>
        /// <param name="trim">
        /// Specifies whether relative vertices are trimmed to the bounds of the shape.
        /// </param>
        /// <param name="sampleLength">
        /// The desired approximate distance between consecutive sampled vertices.
        /// </param>
        /// <returns>
        /// A collection containing the sampled point vertices of each vector path.
        /// </returns>
        public IReadOnlyList<IReadOnlyList<Point2>> GetPointVertices(
            ValueMode valueMode = ValueMode.Absolute,
            bool trim = true,
            float sampleLength = DefaultSampleLength)
        {
            if (sampleLength <= 0f)
                throw new ArgumentOutOfRangeException(nameof(sampleLength));

            var polygons = new IReadOnlyList<Point2>[Paths.Count];

            for (int i = 0; i < Paths.Count; i++)
                polygons[i] = Paths[i].GetVertices(sampleLength);

            if (valueMode == ValueMode.Absolute)
                return polygons;

            if (!TryGetBounds(out Bounds2 bounds, sampleLength))
                return polygons;

            float width = bounds.Size.Width;
            float height = bounds.Size.Height;

            for (int i = 0; i < polygons.Length; i++)
            {
                IReadOnlyList<Point2> points = polygons[i];
                var relative = new Point2[points.Count];

                for (int j = 0; j < points.Count; j++)
                {
                    Point2 point = points[j];

                    relative[j] = new Point2(
                        width != 0f ? (point.X - (trim ? bounds.X : 0f)) / width : 0f,
                        height != 0f ? (point.Y - (trim ? bounds.Y : 0f)) / height : 0f);
                }

                polygons[i] = relative;
            }

            return polygons;
        }

        /// <summary>
        /// Gets the sampled vector vertices of all vector paths.
        /// </summary>
        /// <param name="valueMode">
        /// Specifies whether the returned vertices use absolute or relative coordinates.
        /// </param>
        /// <param name="trim">
        /// Specifies whether relative vertices are trimmed to the bounds of the shape.
        /// </param>
        /// <param name="sampleLength">
        /// The desired approximate distance between consecutive sampled vertices.
        /// </param>
        /// <returns>
        /// A collection containing the sampled vector vertices of each vector path.
        /// </returns>
        public IReadOnlyList<IReadOnlyList<Vector2>> GetVectorVertices(
            ValueMode valueMode = ValueMode.Absolute,
            bool trim = true,
            float sampleLength = DefaultSampleLength)
        {
            IReadOnlyList<IReadOnlyList<Point2>> pointPolygons =
                GetPointVertices(valueMode, trim, sampleLength);

            var polygons = new IReadOnlyList<Vector2>[pointPolygons.Count];

            for (int i = 0; i < pointPolygons.Count; i++)
            {
                IReadOnlyList<Point2> points = pointPolygons[i];
                var vectors = new Vector2[points.Count];

                for (int j = 0; j < points.Count; j++)
                    vectors[j] = new Vector2(points[j].X, points[j].Y);

                polygons[i] = vectors;
            }

            return polygons;
        }

        /// <summary>
        /// Attempts to calculate the bounds of all sampled vector paths.
        /// </summary>
        /// <param name="bounds">
        /// Receives the bounds of the complete vector shape when successful.
        /// </param>
        /// <param name="sampleLength">
        /// The desired approximate distance between consecutive sampled vertices.
        /// </param>
        /// <returns>
        /// <see langword="true"/> when the shape contains at least one vertex;
        /// otherwise, <see langword="false"/>.
        /// </returns>
        public bool TryGetBounds(
            out Bounds2 bounds,
            float sampleLength = DefaultSampleLength)
        {
            if (sampleLength <= 0f)
                throw new ArgumentOutOfRangeException(nameof(sampleLength));

            float minX = float.MaxValue;
            float minY = float.MaxValue;
            float maxX = float.MinValue;
            float maxY = float.MinValue;
            bool hasVertex = false;

            for (int i = 0; i < Paths.Count; i++)
            {
                Point2[] vertices = Paths[i].GetVertices(sampleLength);

                for (int j = 0; j < vertices.Length; j++)
                {
                    Point2 vertex = vertices[j];

                    minX = MathF.Min(minX, vertex.X);
                    minY = MathF.Min(minY, vertex.Y);
                    maxX = MathF.Max(maxX, vertex.X);
                    maxY = MathF.Max(maxY, vertex.Y);
                    hasVertex = true;
                }
            }

            if (!hasVertex)
            {
                bounds = default;
                return false;
            }

            bounds = new Bounds2(
                new Point2(minX, minY),
                new Size2(maxX - minX, maxY - minY));

            return true;
        }

        // Only used by VectorPathTool.
        internal void ApplyTransform()
        {
            if (_transformState == null || !_transformState.IsChanged)
                return;

            // Apply the transform changes to the vector geometry.

            _transformState.UpdateState();
        }
    }
}