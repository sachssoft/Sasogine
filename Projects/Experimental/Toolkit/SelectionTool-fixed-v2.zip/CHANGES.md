# Changes

## Experimental namespace

- Moved SelectionTool implementation namespaces to `Sachssoft.Sasogine.Experimental.Components.Tools` and `.Selection`.
- Existing selection target/capability interfaces remain referenced from `Sachssoft.Sasogine.Components.Tools.Selection`.

## Transform lifecycle

- Added `IsTransforming`.
- Added `TransformStarted` and `TransformCompleted` events.
- Added `ConsumeTransformCompleted()` for polling-based integrations.
- Transform completion is now also handled when the pointer is released outside the viewport.
- Cancellation clears the active transform state without reporting a completed transform.

## Drag and snapping fixes

- Fixed first-drag behavior so clicking an unselected movable target can select and begin dragging in the same interaction.
- Move dragging now derives position from the drag-start position and absolute cursor displacement for both snapped and unsnapped movement, avoiding accumulated drift.
- Grid, angle, and pivot midpoint snapping now use deterministic `MidpointRounding.AwayFromZero`.
